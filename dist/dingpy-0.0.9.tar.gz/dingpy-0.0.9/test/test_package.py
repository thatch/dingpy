import dingpy

