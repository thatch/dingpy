from .Alarm import Alarm

def main():
    # alarm_config = Alarm.load_config()
    # alarm = Alarm(alarm_config)
    alarm = Alarm()
    alarm.ring()

if __name__ == "__main__":
    main()

