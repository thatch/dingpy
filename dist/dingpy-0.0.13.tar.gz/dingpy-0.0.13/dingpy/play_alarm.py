# from alarm import Alarm

# class PlayAlarm:
#     def __init__(self, alarm, alarm_config):
#         # create an alarm instance
#         super(Alarm, self).__init__(alarm_config)

#     def ring_alarm(self):
        


# def main():
#     ding = None
#     if len(sys.argv) > 2:
#         print("usage: %s [keyword]" % sys.argv[0])
#         sys.exit(1)

#     ding = Ding()
#     ding.connect()

#     message = None
#     if len(sys.argv) > 1:
#         message = sys.argv[1]
#     ding.ding(message)

# if __name__ == "__main__":
#     main()