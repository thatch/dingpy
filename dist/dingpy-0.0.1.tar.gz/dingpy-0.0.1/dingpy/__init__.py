from ding import Alarm

alarm = Alarm()
alarm.ring_alarm()