# ding

A Python package that plays an audio alert when your program finishes.

Test audio downloaded from: http://soundbible.com/2185-Old-School-Bell.html
